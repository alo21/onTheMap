//
//  TableCell.swift
//  onTheMap
//
//  Created by Alessandro Losavio on 05/03/2019.
//  Copyright © 2019 Losavio. All rights reserved.
//

import Foundation
import UIKit

class StudentCell: UITableViewCell {
    
    @IBOutlet weak var fullnameLabel: UILabel!
    @IBOutlet weak var LinkText: UILabel!
    
    
}
