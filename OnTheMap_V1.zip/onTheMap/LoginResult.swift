//
//  LoginResult.swift
//  onTheMap
//
//  Created by Alessandro Losavio on 09/03/2019.
//  Copyright © 2019 Losavio. All rights reserved.
//

import Foundation

struct LoginResult: Codable {
    let status: Int
    let error: String
}
