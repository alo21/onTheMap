//
//  StudentsInfoResults.swift
//  onTheMap
//
//  Created by Alessandro Losavio on 04/03/2019.
//  Copyright © 2019 Losavio. All rights reserved.
//

import Foundation


struct StudentsInfoResults: Codable{
    let results: [StudentInformation]
}
